# rcognita-qcar

This versiton includes:
- Forklift model
- Trajectory tracking with Stanley Controller and MPC
