# Qcar
Qcar_ws: SLAM and Navigation

For mapping
```
1. roslaunch qcar qcar.launch
2. roslaunch qcar qcar_gmapping.launch
3. rosrun teleop_twist_keyboard teleop_twist_keyboard.py
```
Save the map after exploring.

For navigation
```
1. roslaunch qcar qcar.launch
2. roslaunch qcar navigation.launch
```
