#!/bin/bash

cd /qcar_ws \
     && . /opt/ros/noetic/setup.sh \
     && catkin_make
   
exec bash

