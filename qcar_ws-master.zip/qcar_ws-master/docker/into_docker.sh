#!/usr/bin/env bash

sudo docker exec -ti ros-qcar bash
